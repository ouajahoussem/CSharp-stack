#pragma warning disable CS8618
namespace DojoSurveyWithModel.Models;

public class Student
{
    public string Name;
    public string Location;
    public string FavoriteLanguage;
    public string Comment;

}